/*-------------------------------------------------------------------
 * Converts from an AXI-MM read channel to AXI Stream interface
 *
 * Arguments
 *   len: length of transfer
 *   aximm_rd: AXI-MM interface
 *   axis_out: AXI Stream master
 -------------------------------------------------------------------*/

#include "aximm2axis.h"

void aximm2axis(TLEN_t len, TDATA_t *aximm_rd, TDATA_t &axis_out)

{
    // implement axis_out as AXI Stream interface - do not remove
    #pragma HLS INTERFACE axis register both depth=256 port=axis_out

    // implement aximm_rd as AXI-MM interface with separate address offset port
    #pragma HLS INTERFACE m_axi depth=256 port=aximm_rd offset=direct max_read_burst_length=256

	// implement aximm_rd as AXI-MM interface with offset address as register controlled by AXI-Lite
    //#pragma HLS INTERFACE m_axi depth=256 port=aximm_rd offset=slave max_read_burst_length=256

	// Use these pragmas to bundle the len & control ports into an AXI-Lite interface
    //#pragma HLS INTERFACE s_axilite port=len     bundle=AXILite
    //#pragma HLS INTERFACE s_axilite port=return  bundle=AXILite

    // this pragma ensures that AXI-MM and AXIS transactions can occur in parallel - do not remove
    #pragma HLS DATAFLOW


    // HLS stream will be implemented as a FIFO of depth 16
	// user can change FIFO depth as required with "depth" option
	hls::stream<TDATA_t> mm2str_fifo;
    #pragma HLS STREAM variable=mm2str_fifo depth=16 dim=1


	// read from the AXI-MM interface to the FIFO
	// must use the PIPELINE pragma to get burst reads
	loop0: for (int i=0; i < len; i++) {
    #pragma HLS LOOP_TRIPCOUNT avg=256
    #pragma HLS PIPELINE II=1
		mm2str_fifo << aximm_rd[i];
	}

    // Execute read from the FIFO, then write out to the AXI Stream interface
	loop1: for (int i=0; i < len; i++) {
    #pragma HLS LOOP_TRIPCOUNT avg=256
    #pragma HLS PIPELINE II=1
		mm2str_fifo >> axis_out;            // read from FIFO
		cout << axis_out << endl;           // debug only
	}


}


