/*-------------------------------------------------------------------
 * testbench for AXI-MM master interface to AXI Stream interface
 -------------------------------------------------------------------*/

#include "../src/aximm2axis.h"


int main(void)
{
	TDATA_t din[256];
	TDATA_t dout;
	TLEN_t len = 37;   // # of transactions

    // fill array of data - will be read by AXI-MM
	for (int i=0; i<256; i++) {
		din[i] = i;
	}

	// call function under test
	aximm2axis(len, din, dout);


	len = 16;   // # of transactions
	// call function under test
	aximm2axis(len, din, dout);


	return 0;

}
